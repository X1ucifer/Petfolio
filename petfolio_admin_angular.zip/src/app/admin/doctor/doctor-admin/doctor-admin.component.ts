import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-doctor-admin',
  templateUrl: './doctor-admin.component.html',
  styleUrls: ['./doctor-admin.component.css']
})
export class DoctorAdminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
