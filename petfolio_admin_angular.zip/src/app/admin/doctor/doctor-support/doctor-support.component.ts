import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-doctor-support',
  templateUrl: './doctor-support.component.html',
  styleUrls: ['./doctor-support.component.css']
})
export class DoctorSupportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
