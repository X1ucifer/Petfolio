import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payemntvendor',
  templateUrl: './payemntvendor.component.html',
  styleUrls: ['./payemntvendor.component.css']
})
export class PayemntvendorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
