import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pet-care-payment',
  templateUrl: './pet-care-payment.component.html',
  styleUrls: ['./pet-care-payment.component.css']
})
export class PetCarePaymentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
