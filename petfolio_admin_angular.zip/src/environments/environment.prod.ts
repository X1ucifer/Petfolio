export const environment = {
  production: true,

  //Dev URL///

  apiUrl: 'http://54.212.108.156:3000/api/',
  imageURL: 'http://54.212.108.156:3000/api/'




   //Live URL//

  //  apiUrl: 'http://52.25.163.13:3000/api/',

  //  imageURL: 'http://52.25.163.13:3000/api/'







  // apiUrl: 'http://localhost:91/'
};

